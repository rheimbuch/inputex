<?php
   echo stripslashes($_POST["value"]);
?>